<?php
/**
 * قالب برگه‌های ثابت
 * صفحاتی که با المنتور ساخته شده‌اند، بدون گرید/سایدبار قالب و به‌صورت تمام‌عرض
 * نمایش داده می‌شوند تا کانتینرهای خود المنتور کنترل چیدمان را برعهده بگیرند.
 */
get_header();

$soswp_is_elementor = function_exists( 'soswp_is_built_with_elementor' ) && soswp_is_built_with_elementor();
?>

<?php if ( $soswp_is_elementor ) : ?>

	<?php while ( have_posts() ) : the_post(); ?>
		<?php the_content(); ?>
	<?php endwhile; ?>

<?php else : ?>

	<div class="content-wrap">
		<div class="wrap">
			<main>
				<?php while ( have_posts() ) : the_post(); ?>
					<article <?php post_class(); ?>>
						<h1><?php the_title(); ?></h1>
						<div class="entry-content">
							<?php the_content(); ?>
						</div>
					</article>
					<?php
					if ( comments_open() || get_comments_number() ) {
						comments_template();
					}
					?>
				<?php endwhile; ?>
			</main>
			<?php get_sidebar(); ?>
		</div>
	</div>

<?php endif; ?>

<?php get_footer(); ?>
