	<?php
	/**
	 * اگر در المنتور پرو (Theme Builder) یک قالب فوتر اختصاصی به این سایت اختصاص داده شده،
	 * همان نمایش داده می‌شود و فوتر پیش‌فرض قالب رندر نمی‌شود.
	 */
	if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'footer' ) ) :
	?>
	<footer class="site-footer">
		<div class="wrap">
			<div class="footer-grid">
				<div>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-logo" style="margin-bottom:14px;">
						<span class="site-logo__mark">SOS</span>
						<span><?php bloginfo( 'name' ); ?></span>
					</a>
					<p style="max-width:32ch;">
						تیم پشتیبانی فنی وردپرس، آماده رسیدگی به بحرانی‌ترین مشکلات سایت شما در کمترین زمان ممکن.
					</p>
				</div>

				<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
					<div><?php dynamic_sidebar( 'footer-1' ); ?></div>
				<?php else : ?>
					<div>
						<h4 class="footer-widget__title">دسترسی سریع</h4>
						<?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'menu_class' => '', 'fallback_cb' => false ) ); ?>
					</div>
				<?php endif; ?>

				<?php if ( is_active_sidebar( 'footer-2' ) ) : ?>
					<div><?php dynamic_sidebar( 'footer-2' ); ?></div>
				<?php else : ?>
					<div>
						<h4 class="footer-widget__title">تماس اضطراری</h4>
						<p class="mono" style="direction:ltr;text-align:right;">
							<?php echo esc_html( soswp_option( 'phone' ) ); ?>
						</p>
						<p><a href="<?php echo esc_url( soswp_option( 'whatsapp' ) ); ?>">پیام در تلگرام</a></p>
					</div>
				<?php endif; ?>

				<div>
					<h4 class="footer-widget__title">وضعیت زنده</h4>
					<p>میانگین پاسخ‌گویی: <b class="mono"><?php echo esc_html( soswp_option( 'avg_response' ) ); ?></b></p>
					<p>نرخ بازیابی موفق: <b class="mono"><?php echo esc_html( soswp_option( 'uptime_stat' ) ); ?></b></p>
				</div>
			</div>

			<div class="footer-bottom">
				<span>© <?php echo esc_html( date_i18n( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?> — تمامی حقوق محفوظ است.</span>
				<span>ساخته‌شده برای رسیدگی سریع به سایت‌های وردپرسی</span>
			</div>
		</div>
	</footer>
	<?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>
