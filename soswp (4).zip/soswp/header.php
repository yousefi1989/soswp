<?php
/**
 * هدر قالب SOSWP
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'soswp' ); ?>>
<?php wp_body_open(); ?>

<?php
/**
 * اگر در المنتور پرو (Theme Builder) یک قالب هدر اختصاصی به این سایت اختصاص داده شده،
 * همان نمایش داده می‌شود و هدر پیش‌فرض قالب رندر نمی‌شود.
 */
if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'header' ) ) :
?>
<div class="status-bar">
	<div class="wrap">
		<div class="status-bar__live">
			<span class="dot" aria-hidden="true"></span>
			<span><?php echo esc_html( soswp_option( 'hero_badge' ) ); ?></span>
		</div>
		<a class="status-bar__phone" href="tel:<?php echo esc_attr( soswp_option( 'phone_tel' ) ); ?>">
			خط اضطرار: <span><?php echo esc_html( soswp_option( 'phone' ) ); ?></span>
		</a>
	</div>
</div>

<header class="site-header">
	<div class="wrap">
		<?php if ( has_custom_logo() ) : ?>
			<?php the_custom_logo(); ?>
		<?php else : ?>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-logo">
				<span class="site-logo__mark">SOS</span>
				<span>
					<?php bloginfo( 'name' ); ?>
					<small>WORDPRESS RESCUE</small>
				</span>
			</a>
		<?php endif; ?>

		<?php
		wp_nav_menu( array(
			'theme_location' => 'primary',
			'container'      => false,
			'menu_class'     => 'primary-menu',
			'fallback_cb'    => 'soswp_fallback_menu',
		) );
		?>

		<div class="header-cta">
			<a href="#emergency-form" class="btn btn--primary">درخواست اضطراری</a>
			<button class="menu-toggle" aria-label="باز کردن منو">☰</button>
		</div>
	</div>
</header>
<?php endif; ?>

<?php
function soswp_fallback_menu() {
	echo '<ul class="primary-menu">
		<li><a href="#services">خدمات</a></li>
		<li><a href="#process">روند کار</a></li>
		<li><a href="#plans">تعرفه‌ها</a></li>
		<li><a href="#faq">سوالات متداول</a></li>
	</ul>';
}
