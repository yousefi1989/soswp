<article <?php post_class( 'service-card' ); ?> style="margin-bottom:20px;">
	<div class="service-card__top">
		<h3><a href="<?php the_permalink(); ?>" style="text-decoration:none;"><?php the_title(); ?></a></h3>
		<span class="severity severity--normal mono"><?php echo esc_html( get_the_date() ); ?></span>
	</div>
	<?php the_excerpt(); ?>
	<a href="<?php the_permalink(); ?>" class="btn btn--ghost">ادامه مطلب</a>
</article>
