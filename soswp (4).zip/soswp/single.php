<?php
/**
 * قالب تک‌نوشته
 * در صورت ساخته‌شدن نوشته با المنتور، خروجی تمام‌عرض و بدون گرید/سایدبار قالب است.
 */
get_header();

$soswp_is_elementor = function_exists( 'soswp_is_built_with_elementor' ) && soswp_is_built_with_elementor();
?>

<?php if ( $soswp_is_elementor ) : ?>

	<?php while ( have_posts() ) : the_post(); ?>
		<?php the_content(); ?>
	<?php endwhile; ?>

<?php else : ?>

	<div class="content-wrap">
		<div class="wrap">
			<main>
				<?php while ( have_posts() ) : the_post(); ?>
					<article <?php post_class(); ?>>
						<span class="eyebrow">// <?php echo esc_html( get_the_date() ); ?></span>
						<h1><?php the_title(); ?></h1>
						<?php if ( has_post_thumbnail() ) : ?>
							<div style="margin-bottom:24px;"><?php the_post_thumbnail( 'large' ); ?></div>
						<?php endif; ?>
						<div class="entry-content">
							<?php the_content(); ?>
						</div>
					</article>
					<?php
					if ( comments_open() || get_comments_number() ) {
						comments_template();
					}
					?>
				<?php endwhile; ?>
			</main>
			<?php get_sidebar(); ?>
		</div>
	</div>

<?php endif; ?>

<?php get_footer(); ?>
