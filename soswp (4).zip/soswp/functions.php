<?php
/**
 * SOSWP — توابع پایه قالب
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SOSWP_VERSION', '1.1.0' );
define( 'SOSWP_DIR', get_template_directory() );
define( 'SOSWP_URI', get_template_directory_uri() );

/** راه‌اندازی پایه قالب */
function soswp_setup() {
	load_theme_textdomain( 'soswp', SOSWP_DIR . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array(
		'height'      => 64,
		'width'       => 200,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'responsive-embeds' );

	register_nav_menus( array(
		'primary' => __( 'منوی اصلی', 'soswp' ),
		'footer'  => __( 'منوی فوتر', 'soswp' ),
	) );
}
add_action( 'after_setup_theme', 'soswp_setup' );

/** بارگذاری استایل‌ها و اسکریپت‌ها */
function soswp_scripts() {
	// فونت‌ها
	wp_enqueue_style( 'soswp-fonts', 'https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;700;800;900&family=JetBrains+Mono:wght@400;600&display=swap', array(), null );

	wp_enqueue_style( 'soswp-style', get_stylesheet_uri(), array(), SOSWP_VERSION );
	wp_enqueue_style( 'soswp-main', SOSWP_URI . '/assets/css/main.css', array( 'soswp-style' ), SOSWP_VERSION );

	wp_enqueue_script( 'soswp-main', SOSWP_URI . '/assets/js/main.js', array(), SOSWP_VERSION, true );

	wp_localize_script( 'soswp-main', 'soswpData', array(
		'avgResponse'   => soswp_option( 'avg_response', '۸ دقیقه' ),
		'ticketsToday'  => soswp_option( 'tickets_today', '۲۷' ),
	) );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'soswp_scripts' );

/** ناحیه‌های ابزارک فوتر */
function soswp_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'فوتر — ستون ۱', 'soswp' ),
		'id'            => 'footer-1',
		'before_widget' => '<div class="footer-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="footer-widget__title">',
		'after_title'   => '</h4>',
	) );
	register_sidebar( array(
		'name'          => __( 'فوتر — ستون ۲', 'soswp' ),
		'id'            => 'footer-2',
		'before_widget' => '<div class="footer-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="footer-widget__title">',
		'after_title'   => '</h4>',
	) );
	register_sidebar( array(
		'name'          => __( 'سایدبار', 'soswp' ),
		'id'            => 'sidebar-1',
		'before_widget' => '<div class="widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="widget__title">',
		'after_title'   => '</h4>',
	) );
}
add_action( 'widgets_init', 'soswp_widgets_init' );

/* =========================================================
 * پنل تنظیمات یکپارچه (جایگزین فیلدهای پراکنده کاستومایزر)
 * ========================================================= */
require_once SOSWP_DIR . '/inc/settings-panel.php';

/** عرض محتوا برای امبدها — هماهنگ با متغیر --wrap در main.css */
if ( ! isset( $content_width ) ) $content_width = 1180;

/* =========================================================
 * هماهنگی با المنتور (Elementor / Elementor Pro)
 * ========================================================= */

/** اعلام پشتیبانی کامل از المنتور */
function soswp_elementor_support() {
	add_theme_support( 'elementor' );
	// اجازه می‌دهد المنتور پرو (Theme Builder) هدر/فوتر/محتوای تک‌نوشته را مدیریت کند.
	add_theme_support( 'elementor-header-footer' );
}
add_action( 'after_setup_theme', 'soswp_elementor_support' );

/** ثبت لوکیشن‌های استاندارد المنتور پرو (هدر، فوتر، تک‌نوشته، آرشیو، ۴۰۴) */
function soswp_register_elementor_locations( $elementor_theme_manager ) {
	$elementor_theme_manager->register_all_core_location();
}
add_action( 'elementor/theme/register_locations', 'soswp_register_elementor_locations' );

/** آیا صفحه جاری با المنتور ساخته شده؟ */
function soswp_is_built_with_elementor( $post_id = null ) {
	if ( ! did_action( 'elementor/loaded' ) ) {
		return false;
	}
	$post_id = $post_id ? $post_id : get_the_ID();
	return $post_id && \Elementor\Plugin::$instance->documents->get( $post_id )->is_built_with_elementor();
}

/** کلاس body برای صفحات ساخته‌شده با المنتور — جهت غیرفعال‌سازی گرید/سایدبار قالب */
function soswp_body_classes( $classes ) {
	if ( is_singular() && soswp_is_built_with_elementor() ) {
		$classes[] = 'soswp-elementor-page';
	}
	// اگر المنتور پرو نصب و لوکیشن هدر/فوتر اختصاصی تعریف شده باشد.
	if ( function_exists( 'elementor_theme_do_location' ) ) {
		$classes[] = 'soswp-ep-active';
	}
	return $classes;
}
add_filter( 'body_class', 'soswp_body_classes' );

/** پیمایش صفحات (نسخه ساده) */
function soswp_pagination() {
	the_posts_pagination( array(
		'mid_size'  => 1,
		'prev_text' => __( '« قبلی', 'soswp' ),
		'next_text' => __( 'بعدی »', 'soswp' ),
	) );
}
