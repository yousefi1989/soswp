<?php
/**
 * صفحه اصلی SOSWP — اتاق دیسپچ پشتیبانی وردپرس
 *
 * اگر برگه‌ی انتخاب‌شده به‌عنوان صفحه اصلی با المنتور ساخته و طراحی شده باشد
 * (مثلاً کاربر می‌خواهد خودش هوم‌پیج را در المنتور بسازد)، همان محتوا نمایش
 * داده می‌شود و طرح آماده SOSWP رندر نمی‌شود.
 */
get_header();

if ( function_exists( 'soswp_is_built_with_elementor' ) && soswp_is_built_with_elementor() ) {
	while ( have_posts() ) {
		the_post();
		the_content();
	}
	get_footer();
	return;
}
?>

<main id="main">

	<!-- ===== هیرو ===== -->
	<section class="hero">
		<div class="wrap">
			<div class="hero__copy">
				<span class="hero__badge">
					<span class="dot" aria-hidden="true"></span> <?php echo esc_html( soswp_option( 'hero_online_badge' ) ); ?>
				</span>
				<h1 class="hero__title">
					<?php echo esc_html( soswp_option( 'hero_title_pre' ) ); ?> <span class="accent"><?php echo esc_html( soswp_option( 'hero_title_accent' ) ); ?></span>؟<br>
					<?php echo esc_html( soswp_option( 'hero_title_post' ) ); ?>
				</h1>
				<p class="hero__lead">
					<?php echo esc_html( soswp_option( 'hero_lead' ) ); ?>
				</p>
				<div class="hero__ctas">
					<a href="#emergency-form" class="btn btn--primary">🚨 ثبت درخواست اضطراری</a>
					<a href="#services" class="btn btn--ghost">دیدن انواع مشکلات</a>
				</div>
			</div>

			<!-- عنصر امضادار: پنل مانیتور زنده وضعیت سایت -->
			<div class="vitals" aria-hidden="false">
				<div class="vitals__head">
					<span>SITE-VITALS.LOG</span>
					<span class="rec"><span class="dot" aria-hidden="true"></span> LIVE</span>
				</div>
				<svg viewBox="0 0 400 110" preserveAspectRatio="none">
					<polyline class="vitals__line" id="soswp-ecg"
						points="0,55 30,55 42,55 50,20 58,90 66,55 90,55 120,55 132,55 140,15 148,95 156,55 180,55 210,55 222,55 230,25 238,88 246,55 280,55 310,55 322,55 330,18 338,92 346,55 400,55" />
				</svg>
				<div class="vitals__stats">
					<div class="vitals__stat">
						<b class="mono" id="soswp-response"><?php echo esc_html( soswp_option( 'avg_response' ) ); ?></b>
						<span>میانگین پاسخ</span>
					</div>
					<div class="vitals__stat">
						<b class="mono" id="soswp-tickets"><?php echo esc_html( soswp_option( 'tickets_today' ) ); ?></b>
						<span>تیکت امروز</span>
					</div>
					<div class="vitals__stat">
						<b class="mono"><?php echo esc_html( soswp_option( 'uptime_stat' ) ); ?></b>
						<span>نرخ بازیابی</span>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- ===== نوار آمار ===== -->
	<section class="stats-strip">
		<div class="wrap">
			<div class="stats-strip__item"><b><?php echo esc_html( soswp_option( 'stat_rescued' ) ); ?></b><span>سایت نجات‌یافته</span></div>
			<div class="stats-strip__item"><b><?php echo esc_html( soswp_option( 'stat_start_time' ) ); ?></b><span>میانگین شروع رسیدگی</span></div>
			<div class="stats-strip__item"><b>۲۴/۷</b><span>پشتیبانی بی‌وقفه</span></div>
			<div class="stats-strip__item"><b><?php echo esc_html( soswp_option( 'stat_satisfaction' ) ); ?></b><span>رضایت مشتریان</span></div>
		</div>
	</section>

	<!-- ===== سرویس‌ها ===== -->
	<section class="section" id="services">
		<div class="wrap">
			<div class="section__head">
				<span class="eyebrow">// انواع فوریت</span>
				<h2>هر بحرانی، یک پروتکل مشخص</h2>
				<p>هر مشکل رده‌بندی می‌شود تا مناسب‌ترین تکنسین بلافاصله وارد عمل شود.</p>
			</div>
			<div class="services">
				<?php foreach ( soswp_option( 'services', array() ) as $svc ) : ?>
					<div class="service-card">
						<div class="service-card__top">
							<span class="service-card__icon"><?php echo esc_html( $svc['icon'] ); ?></span>
							<span class="severity severity--<?php echo esc_attr( $svc['severity'] ); ?>"><?php echo esc_html( soswp_severity_label( $svc['severity'] ) ); ?></span>
						</div>
						<h3><?php echo esc_html( $svc['title'] ); ?></h3>
						<p><?php echo esc_html( $svc['desc'] ); ?></p>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<!-- ===== روند کار ===== -->
	<section class="section" id="process" style="border-top:1px solid var(--line);">
		<div class="wrap">
			<div class="section__head">
				<span class="eyebrow">// پروتکل رسیدگی</span>
				<h2>از ثبت تیکت تا رفع مشکل، ۳ مرحله</h2>
			</div>
			<div class="process">
				<div class="process-step">
					<div class="process-step__num">۱</div>
					<h3>دیسپچ فوری</h3>
					<p>فرم اضطراری را پر می‌کنید؛ تیکت شما با اولویت رده‌بندی می‌شود و به تکنسین در دسترس ارجاع داده می‌شود.</p>
				</div>
				<div class="process-step">
					<div class="process-step__num">۲</div>
					<h3>تشخیص و گزارش</h3>
					<p>علت اصلی مشکل شناسایی و پیش از هرگونه تغییر، گزارش شفاف و برآورد زمان برای شما ارسال می‌شود.</p>
				</div>
				<div class="process-step">
					<div class="process-step__num">۳</div>
					<h3>رفع و پایش</h3>
					<p>مشکل برطرف و سایت ۴۸ ساعت تحت پایش قرار می‌گیرد تا از پایداری کامل آن مطمئن شویم.</p>
				</div>
			</div>
		</div>
	</section>

	<!-- ===== نظرات ===== -->
	<section class="section" style="border-top:1px solid var(--line);">
		<div class="wrap">
			<div class="section__head">
				<span class="eyebrow">// گزارش تیکت‌های بسته‌شده</span>
				<h2>حرف مشتریانی که همین بحران را از سر گذرانده‌اند</h2>
			</div>
			<div class="testimonials">
				<div class="t-card">
					<span class="t-card__ticket">#SOS-2471 · بازیابی از هک</span>
					<p>«نیمه‌شب سایت فروشگاهم هک شده بود، تا صبح کامل پاک‌سازی و ایمن شده بود.»</p>
					<div class="t-card__foot">
						<div class="t-avatar"></div>
						<div><span class="t-name">مدیر فروشگاه آنلاین لوازم خانگی</span><span class="t-role">مشتری از ۱۴۰۲</span></div>
					</div>
				</div>
				<div class="t-card">
					<span class="t-card__ticket">#SOS-2508 · صفحه سفید</span>
					<p>«با یک آپدیت افزونه کل سایت سفید شد. کمتر از یک ساعت همه‌چیز درست شد.»</p>
					<div class="t-card__foot">
						<div class="t-avatar"></div>
						<div><span class="t-name">مدیر وبلاگ آموزشی</span><span class="t-role">مشتری از ۱۴۰۳</span></div>
					</div>
				</div>
				<div class="t-card">
					<span class="t-card__ticket">#SOS-2593 · بهینه‌سازی سرعت</span>
					<p>«زمان بارگذاری از ۹ ثانیه به زیر ۲ ثانیه رسید. نرخ فروش هم واقعاً بالا رفت.»</p>
					<div class="t-card__foot">
						<div class="t-avatar"></div>
						<div><span class="t-name">مدیر سایت خدمات مالی</span><span class="t-role">مشتری از ۱۴۰۳</span></div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- ===== تعرفه‌ها ===== -->
	<section class="section" id="plans" style="border-top:1px solid var(--line);">
		<div class="wrap">
			<div class="section__head">
				<span class="eyebrow">// تعرفه‌ها</span>
				<h2>پرداخت فقط برای همان بحرانی که دارید</h2>
			</div>
			<div class="plans">
				<div class="plan">
					<h3>رفع اضطراری تکی</h3>
					<div class="plan__price">۴۹۰ <span>هزار تومان</span></div>
					<ul>
						<li>رفع یک مشکل مشخص</li>
						<li>پاسخ‌گویی زیر ۱۵ دقیقه</li>
						<li>۷ روز ضمانت رفع مشکل</li>
					</ul>
					<a href="#emergency-form" class="btn btn--ghost">شروع درخواست</a>
				</div>
				<div class="plan plan--featured">
					<h3>پشتیبانی ماهانه</h3>
					<div class="plan__price">۱٬۹۰۰ <span>هزار تومان / ماه</span></div>
					<ul>
						<li>رسیدگی نامحدود به فوریت‌ها</li>
						<li>پشتیبان‌گیری روزانه خودکار</li>
						<li>مانیتورینگ ۲۴ ساعته سایت</li>
						<li>آپدیت و بهینه‌سازی ماهانه</li>
					</ul>
					<a href="#emergency-form" class="btn btn--primary">انتخاب این پلن</a>
				</div>
				<div class="plan">
					<h3>سازمانی / فروشگاهی</h3>
					<div class="plan__price">تماس بگیرید</div>
					<ul>
						<li>SLA اختصاصی و تکنسین ثابت</li>
						<li>پایش زیرساخت و امنیت پیشرفته</li>
						<li>گزارش ماهانه عملکرد</li>
					</ul>
					<a href="tel:<?php echo esc_attr( soswp_option( 'phone_tel' ) ); ?>" class="btn btn--ghost">مشاوره تلفنی</a>
				</div>
			</div>
		</div>
	</section>

	<!-- ===== فرم اضطراری ===== -->
	<section class="emergency" id="emergency-form">
		<div class="wrap">
			<div>
				<span class="eyebrow">// ثبت تیکت</span>
				<h2>الان مشکل دارید؟ فرم را پر کنید.</h2>
				<p>هرچه اطلاعات دقیق‌تری بدهید، تشخیص سریع‌تر انجام می‌شود. برای موارد فوری می‌توانید مستقیم تماس بگیرید:
				<a class="mono" style="color:var(--signal);" href="tel:<?php echo esc_attr( soswp_option( 'phone_tel' ) ); ?>"><?php echo esc_html( soswp_option( 'phone' ) ); ?></a></p>
			</div>
			<form class="soswp-form" method="post" action="#">
				<div class="form-row">
					<label for="soswp-name">نام و نام سایت</label>
					<input type="text" id="soswp-name" name="soswp_name" required>
				</div>
				<div class="form-row">
					<label for="soswp-url">آدرس سایت</label>
					<input type="url" id="soswp-url" name="soswp_url" placeholder="https://example.com" required>
				</div>
				<div class="form-row">
					<label for="soswp-severity">سطح فوریت</label>
					<select id="soswp-severity" name="soswp_severity">
						<option>بحرانی — سایت کاملاً از دسترس خارج است</option>
						<option>جدی — بخشی از سایت کار نمی‌کند</option>
						<option>متوسط — نیاز به بررسی و نگهداری دارم</option>
					</select>
				</div>
				<div class="form-row">
					<label for="soswp-desc">توضیح مشکل</label>
					<textarea id="soswp-desc" name="soswp_desc" rows="4"></textarea>
				</div>
				<button type="submit" class="btn btn--primary" style="width:100%; justify-content:center;">🚨 ارسال تیکت اضطراری</button>
			</form>
		</div>
	</section>

</main>

<?php get_footer(); ?>
