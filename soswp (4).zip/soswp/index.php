<?php
/**
 * قالب پیش‌فرض فهرست نوشته‌ها
 */
get_header();
?>
<div class="content-wrap">
	<div class="wrap">
		<main>
			<?php if ( have_posts() ) : ?>
				<?php while ( have_posts() ) : the_post(); ?>
					<?php get_template_part( 'template-parts/content' ); ?>
				<?php endwhile; ?>
				<?php soswp_pagination(); ?>
			<?php else : ?>
				<div class="service-card">
					<h3>موردی یافت نشد</h3>
					<p>محتوایی برای نمایش وجود ندارد.</p>
				</div>
			<?php endif; ?>
		</main>
		<?php get_sidebar(); ?>
	</div>
</div>
<?php get_footer(); ?>
