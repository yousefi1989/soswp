(function () {
	'use strict';

	// --- منوی موبایل ---
	var toggle = document.querySelector( '.menu-toggle' );
	var menu = document.querySelector( '.primary-menu' );
	if ( toggle && menu ) {
		toggle.addEventListener( 'click', function () {
			var isOpen = menu.style.display === 'flex';
			menu.style.display = isOpen ? 'none' : 'flex';
			menu.style.flexDirection = 'column';
			menu.style.position = 'absolute';
			menu.style.top = '76px';
			menu.style.insetInline = '0';
			menu.style.background = '#101218';
			menu.style.padding = '20px 24px';
			menu.style.borderBottom = '1px solid rgba(245,246,248,.09)';
			toggle.setAttribute( 'aria-expanded', String( ! isOpen ) );
		} );
	}

	// --- انیمیشن خط پالس (ECG) در پنل وایتالز ---
	var line = document.getElementById( 'soswp-ecg' );
	if ( line && ! window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
		var length = line.getTotalLength ? line.getTotalLength() : 800;
		line.style.strokeDasharray = length;
		line.style.strokeDashoffset = length;

		var draw = function () {
			line.style.transition = 'none';
			line.style.strokeDashoffset = length;
			// force reflow
			line.getBoundingClientRect();
			line.style.transition = 'stroke-dashoffset 2.6s linear';
			line.style.strokeDashoffset = 0;
		};
		draw();
		setInterval( draw, 2700 );
	}

	// --- شمارنده ساده برای تیکت‌های امروز (نمایشی، از localized data) ---
	var ticketsEl = document.getElementById( 'soswp-tickets' );
	if ( ticketsEl && window.soswpData ) {
		var base = parseInt( ( soswpData.ticketsToday || '0' ).replace( /[^0-9]/g, '' ), 10 ) || 0;
		var count = base;
		setInterval( function () {
			count += 1;
			ticketsEl.textContent = String( count ).replace( /\d/g, function ( d ) {
				return '۰۱۲۳۴۵۶۷۸۹'[ d ];
			} );
		}, 45000 );
	}
})();
