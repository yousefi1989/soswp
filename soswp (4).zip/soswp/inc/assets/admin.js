(function ($) {
	'use strict';

	$( function () {

		// --- تب‌ها ---
		$( '.soswp-tabs a' ).on( 'click', function () {
			// اجازه بده لینک هم واقعاً navigate کند (پارامتر tab در URL) تا رفرش صفحه هم تب درست را نشان دهد.
			// اما برای تجربه سریع‌تر بدون رفرش هم سوییچ می‌کنیم:
			var tab = $( this ).attr( 'href' ).split( 'tab=' )[1];
			if ( ! tab ) return;
			// اگر جاوااسکریپت فعال است، از رفرش صفحه جلوگیری می‌کنیم.
			$( '.soswp-tabs a' ).removeClass( 'nav-tab-active' );
			$( this ).addClass( 'nav-tab-active' );
			$( '.soswp-tab-panel' ).attr( 'hidden', true );
			$( '.soswp-tab-panel[data-tab="' + tab + '"]' ).attr( 'hidden', false );
			history.replaceState( null, '', $( this ).attr( 'href' ) );
			return false;
		} );

		// --- انتخابگر رنگ ---
		if ( $.fn.wpColorPicker ) {
			$( '.soswp-color-field' ).wpColorPicker();
		}

		// --- ریپیتر خدمات ---
		$( '#soswp-svc-add' ).on( 'click', function () {
			var tpl = document.getElementById( 'soswp-svc-template' );
			var clone = document.importNode( tpl.content, true );
			document.getElementById( 'soswp-services-repeater' ).appendChild( clone );
		} );

		$( document ).on( 'click', '.soswp-svc-remove', function () {
			$( this ).closest( '.soswp-svc-row' ).remove();
		} );
	} );

})( jQuery );
