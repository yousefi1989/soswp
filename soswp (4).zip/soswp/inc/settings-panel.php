<?php
/**
 * پنل تنظیمات یکپارچه SOSWP
 * یک محل واحد برای مدیریت اطلاعات تماس، آمار زنده، محتوای هیرو، رنگ‌بندی و لیست خدمات.
 * این مقادیر هم در صفحات PHP قالب (خانه، هدر، فوتر) و هم به‌صورت متغیرهای رنگی CSS
 * در کل سایت (از جمله صفحات ساخته‌شده با المنتور که از کلاس‌های قالب استفاده می‌کنند) اعمال می‌شوند.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SOSWP_OPTION_KEY', 'soswp_settings' );

/** مقادیر پیش‌فرض تنظیمات */
function soswp_default_settings() {
	return array(
		// عمومی
		'phone'              => '۰۲۱-۹۱۰۰۰۰۰۰',
		'phone_tel'          => '+982191000000',
		'whatsapp'           => 'https://t.me/soswp',
		'email'              => 'support@soswp.ir',
		'address'            => 'تهران، ایران — پشتیبانی کاملاً آنلاین',

		// هیرو
		'hero_badge'         => 'پاسخ‌گویی زنده ۲۴ ساعته — همین حالا آنلاین',
		'hero_online_badge'  => 'در حال حاضر ۴ تکنسین آنلاین‌اند',
		'hero_title_pre'     => 'سایت وردپرسی‌تون',
		'hero_title_accent'  => 'از کار افتاده',
		'hero_title_post'    => 'ما اورژانس فنی وردپرسیم.',
		'hero_lead'          => 'هک شده، وایت‌اسکرین داده، کرش کرده یا فقط کند شده — تیم SOSWP در کمتر از ۱۵ دقیقه تیکت شما را می‌بیند و رسیدگی را شروع می‌کند. بدون قرارداد بلندمدت، بدون معطلی.',

		// آمار زنده
		'avg_response'       => '۸ دقیقه',
		'tickets_today'      => '۲۷',
		'uptime_stat'        => '۹۸٫۴٪',
		'stat_rescued'       => '+۳٬۸۰۰',
		'stat_start_time'    => '۱۲ دقیقه',
		'stat_satisfaction'  => '۹۸٫۴٪',

		// رنگ‌بندی (متغیرهای CSS سراسری)
		'color_ink'          => '#101218',
		'color_ink2'         => '#171A22',
		'color_signal'       => '#FF3B30',
		'color_beacon'       => '#FFB020',
		'color_pulse'        => '#2ECC71',
		'color_cloud'        => '#F5F6F8',
		'color_steel'        => '#8A8F9C',

		// خدمات (نمایش‌داده‌شده در صفحه خانه)
		'services'           => array(
			array( 'icon' => '🦠', 'severity' => 'critical', 'title' => 'سایت هک شده / آلوده به مالور', 'desc' => 'پاک‌سازی کامل، شناسایی نقطه نفوذ و بستن حفره امنیتی قبل از بازگرداندن سایت.' ),
			array( 'icon' => '⬜', 'severity' => 'critical', 'title' => 'صفحه سفید مرگ (White Screen)', 'desc' => 'خطایابی افزونه/قالب و پیکربندی PHP برای بازگشت سریع سایت به حالت عادی.' ),
			array( 'icon' => '💥', 'severity' => 'high',     'title' => 'کرش بعد از آپدیت', 'desc' => 'بازگردانی نسخه پایدار و رفع تداخل بین هسته وردپرس، قالب و افزونه‌ها.' ),
			array( 'icon' => '🐌', 'severity' => 'high',     'title' => 'کندی شدید سایت', 'desc' => 'بهینه‌سازی دیتابیس، کش و سرور برای رساندن زمان بارگذاری به زیر ۲ ثانیه.' ),
			array( 'icon' => '🔑', 'severity' => 'normal',   'title' => 'قفل شدن دسترسی ادمین', 'desc' => 'بازیابی دسترسی مدیریت، ریست امن رمز عبور و بررسی نقش‌های کاربری.' ),
			array( 'icon' => '🛠️', 'severity' => 'normal',   'title' => 'پشتیبانی و نگهداری دوره‌ای', 'desc' => 'آپدیت منظم، پشتیبان‌گیری خودکار و مانیتورینگ پیش‌گیرانه سایت.' ),
		),
	);
}

/** خواندن یک مقدار از تنظیمات یکپارچه (تک نقطه دسترسی برای کل قالب) */
function soswp_option( $key, $fallback = '' ) {
	static $settings = null;
	if ( null === $settings ) {
		$settings = wp_parse_args( get_option( SOSWP_OPTION_KEY, array() ), soswp_default_settings() );
	}
	return isset( $settings[ $key ] ) && '' !== $settings[ $key ] ? $settings[ $key ] : $fallback;
}

/** ثبت منوی پنل تنظیمات در ادمین */
function soswp_settings_menu() {
	add_menu_page(
		'تنظیمات SOSWP',
		'تنظیمات SOSWP',
		'manage_options',
		'soswp-settings',
		'soswp_render_settings_page',
		'dashicons-shield-alt',
		61
	);
}
add_action( 'admin_menu', 'soswp_settings_menu' );

/** بارگذاری استایل/اسکریپت پنل تنظیمات فقط در صفحه خودش */
function soswp_admin_assets( $hook ) {
	if ( 'toplevel_page_soswp-settings' !== $hook ) {
		return;
	}
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_script( 'wp-color-picker' );
	wp_enqueue_style( 'soswp-admin', SOSWP_URI . '/inc/assets/admin.css', array(), SOSWP_VERSION );
	wp_enqueue_script( 'soswp-admin', SOSWP_URI . '/inc/assets/admin.js', array( 'jquery', 'wp-color-picker' ), SOSWP_VERSION, true );
}
add_action( 'admin_enqueue_scripts', 'soswp_admin_assets' );

/** ذخیره‌سازی تنظیمات */
function soswp_save_settings() {
	if ( ! isset( $_POST['soswp_settings_nonce'] ) || ! wp_verify_nonce( $_POST['soswp_settings_nonce'], 'soswp_save_settings' ) ) {
		return;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$defaults = soswp_default_settings();
	$new      = array();

	$text_fields = array(
		'phone', 'phone_tel', 'whatsapp', 'email', 'address',
		'hero_badge', 'hero_online_badge', 'hero_title_pre', 'hero_title_accent', 'hero_title_post',
		'avg_response', 'tickets_today', 'uptime_stat', 'stat_rescued', 'stat_start_time', 'stat_satisfaction',
	);
	foreach ( $text_fields as $field ) {
		if ( isset( $_POST[ $field ] ) ) {
			$new[ $field ] = sanitize_text_field( wp_unslash( $_POST[ $field ] ) );
		}
	}

	if ( isset( $_POST['hero_lead'] ) ) {
		$new['hero_lead'] = sanitize_textarea_field( wp_unslash( $_POST['hero_lead'] ) );
	}

	$color_fields = array( 'color_ink', 'color_ink2', 'color_signal', 'color_beacon', 'color_pulse', 'color_cloud', 'color_steel' );
	foreach ( $color_fields as $field ) {
		if ( isset( $_POST[ $field ] ) ) {
			$new[ $field ] = sanitize_hex_color( wp_unslash( $_POST[ $field ] ) ) ?: $defaults[ $field ];
		}
	}

	$services = array();
	if ( isset( $_POST['svc_title'] ) && is_array( $_POST['svc_title'] ) ) {
		$icons      = wp_unslash( $_POST['svc_icon'] ?? array() );
		$severities = wp_unslash( $_POST['svc_severity'] ?? array() );
		$titles     = wp_unslash( $_POST['svc_title'] ?? array() );
		$descs      = wp_unslash( $_POST['svc_desc'] ?? array() );

		foreach ( $titles as $i => $title ) {
			$title = sanitize_text_field( $title );
			if ( '' === trim( $title ) ) {
				continue;
			}
			$severity = in_array( $severities[ $i ] ?? 'normal', array( 'critical', 'high', 'normal' ), true ) ? $severities[ $i ] : 'normal';
			$services[] = array(
				'icon'     => sanitize_text_field( $icons[ $i ] ?? '🛠️' ),
				'severity' => $severity,
				'title'    => $title,
				'desc'     => sanitize_textarea_field( $descs[ $i ] ?? '' ),
			);
		}
	}
	if ( ! empty( $services ) ) {
		$new['services'] = $services;
	}

	$existing = wp_parse_args( get_option( SOSWP_OPTION_KEY, array() ), $defaults );
	update_option( SOSWP_OPTION_KEY, array_merge( $existing, $new ) );

	add_settings_error( 'soswp_settings', 'soswp_saved', 'تنظیمات با موفقیت ذخیره شد.', 'success' );
}
add_action( 'admin_init', 'soswp_save_settings' );

/** برچسب فارسی سطح فوریت */
function soswp_severity_label( $key ) {
	$map = array( 'critical' => 'بحرانی', 'high' => 'جدی', 'normal' => 'متوسط' );
	return $map[ $key ] ?? 'متوسط';
}

/** رندر صفحه تنظیمات */
function soswp_render_settings_page() {
	$s    = wp_parse_args( get_option( SOSWP_OPTION_KEY, array() ), soswp_default_settings() );
	$tab  = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'general';
	$tabs = array(
		'general'  => 'عمومی',
		'hero'     => 'محتوای هیرو',
		'stats'    => 'آمار زنده',
		'colors'   => 'رنگ‌بندی',
		'services' => 'خدمات',
	);
	?>
	<div class="wrap soswp-settings">
		<div class="soswp-settings__header">
			<span class="soswp-settings__mark">SOS</span>
			<div>
				<h1>پنل تنظیمات یکپارچه SOSWP</h1>
				<p>یک محل واحد برای مدیریت محتوای اضطراری، آمار زنده و رنگ‌بندی کل سایت — از جمله صفحاتی که با المنتور ساخته‌اید.</p>
			</div>
		</div>

		<?php settings_errors( 'soswp_settings' ); ?>

		<h2 class="nav-tab-wrapper soswp-tabs">
			<?php foreach ( $tabs as $key => $label ) : ?>
				<a href="?page=soswp-settings&tab=<?php echo esc_attr( $key ); ?>" class="nav-tab <?php echo $tab === $key ? 'nav-tab-active' : ''; ?>"><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
		</h2>

		<form method="post" class="soswp-form-panel">
			<?php wp_nonce_field( 'soswp_save_settings', 'soswp_settings_nonce' ); ?>

			<div class="soswp-tab-panel" data-tab="general" <?php echo 'general' !== $tab ? 'hidden' : ''; ?>>
				<table class="form-table">
					<tr><th><label for="phone">شماره تماس اضطراری (نمایشی)</label></th><td><input type="text" id="phone" name="phone" value="<?php echo esc_attr( $s['phone'] ); ?>" class="regular-text" dir="ltr"></td></tr>
					<tr><th><label for="phone_tel">شماره برای لینک تماس (tel:)</label></th><td><input type="text" id="phone_tel" name="phone_tel" value="<?php echo esc_attr( $s['phone_tel'] ); ?>" class="regular-text" dir="ltr" placeholder="+982100000000"></td></tr>
					<tr><th><label for="whatsapp">لینک تلگرام / واتس‌اپ</label></th><td><input type="url" id="whatsapp" name="whatsapp" value="<?php echo esc_attr( $s['whatsapp'] ); ?>" class="regular-text" dir="ltr"></td></tr>
					<tr><th><label for="email">ایمیل پشتیبانی</label></th><td><input type="email" id="email" name="email" value="<?php echo esc_attr( $s['email'] ); ?>" class="regular-text" dir="ltr"></td></tr>
					<tr><th><label for="address">آدرس</label></th><td><input type="text" id="address" name="address" value="<?php echo esc_attr( $s['address'] ); ?>" class="regular-text"></td></tr>
				</table>
			</div>

			<div class="soswp-tab-panel" data-tab="hero" <?php echo 'hero' !== $tab ? 'hidden' : ''; ?>>
				<table class="form-table">
					<tr><th><label for="hero_badge">متن نوار وضعیت بالای سایت</label></th><td><input type="text" id="hero_badge" name="hero_badge" value="<?php echo esc_attr( $s['hero_badge'] ); ?>" class="large-text"></td></tr>
					<tr><th><label for="hero_online_badge">برچسب کوچک بالای عنوان هیرو</label></th><td><input type="text" id="hero_online_badge" name="hero_online_badge" value="<?php echo esc_attr( $s['hero_online_badge'] ); ?>" class="large-text"></td></tr>
					<tr><th><label for="hero_title_pre">عنوان هیرو — بخش اول</label></th><td><input type="text" id="hero_title_pre" name="hero_title_pre" value="<?php echo esc_attr( $s['hero_title_pre'] ); ?>" class="large-text"></td></tr>
					<tr><th><label for="hero_title_accent">عنوان هیرو — کلمه هایلایت‌شده (قرمز)</label></th><td><input type="text" id="hero_title_accent" name="hero_title_accent" value="<?php echo esc_attr( $s['hero_title_accent'] ); ?>" class="large-text"></td></tr>
					<tr><th><label for="hero_title_post">عنوان هیرو — خط دوم</label></th><td><input type="text" id="hero_title_post" name="hero_title_post" value="<?php echo esc_attr( $s['hero_title_post'] ); ?>" class="large-text"></td></tr>
					<tr><th><label for="hero_lead">متن توضیحی زیر عنوان</label></th><td><textarea id="hero_lead" name="hero_lead" rows="4" class="large-text"><?php echo esc_textarea( $s['hero_lead'] ); ?></textarea></td></tr>
				</table>
			</div>

			<div class="soswp-tab-panel" data-tab="stats" <?php echo 'stats' !== $tab ? 'hidden' : ''; ?>>
				<table class="form-table">
					<tr><th><label for="avg_response">میانگین زمان پاسخ (پنل وایتالز)</label></th><td><input type="text" id="avg_response" name="avg_response" value="<?php echo esc_attr( $s['avg_response'] ); ?>" class="regular-text"></td></tr>
					<tr><th><label for="tickets_today">تعداد تیکت امروز (پنل وایتالز)</label></th><td><input type="text" id="tickets_today" name="tickets_today" value="<?php echo esc_attr( $s['tickets_today'] ); ?>" class="regular-text"></td></tr>
					<tr><th><label for="uptime_stat">نرخ بازیابی (پنل وایتالز)</label></th><td><input type="text" id="uptime_stat" name="uptime_stat" value="<?php echo esc_attr( $s['uptime_stat'] ); ?>" class="regular-text"></td></tr>
					<tr><th><label for="stat_rescued">تعداد کل سایت‌های نجات‌یافته (نوار آمار)</label></th><td><input type="text" id="stat_rescued" name="stat_rescued" value="<?php echo esc_attr( $s['stat_rescued'] ); ?>" class="regular-text"></td></tr>
					<tr><th><label for="stat_start_time">میانگین شروع رسیدگی (نوار آمار)</label></th><td><input type="text" id="stat_start_time" name="stat_start_time" value="<?php echo esc_attr( $s['stat_start_time'] ); ?>" class="regular-text"></td></tr>
					<tr><th><label for="stat_satisfaction">درصد رضایت مشتریان (نوار آمار)</label></th><td><input type="text" id="stat_satisfaction" name="stat_satisfaction" value="<?php echo esc_attr( $s['stat_satisfaction'] ); ?>" class="regular-text"></td></tr>
				</table>
			</div>

			<div class="soswp-tab-panel" data-tab="colors" <?php echo 'colors' !== $tab ? 'hidden' : ''; ?>>
				<p class="description">این رنگ‌ها به‌صورت متغیر CSS سراسری تزریق می‌شوند؛ روی کل سایت — از جمله صفحاتی که با المنتور و کلاس‌های قالب ساخته‌اید — اعمال خواهند شد.</p>
				<table class="form-table">
					<tr><th>پس‌زمینه اصلی</th><td><input type="text" name="color_ink" value="<?php echo esc_attr( $s['color_ink'] ); ?>" class="soswp-color-field"></td></tr>
					<tr><th>پس‌زمینه کارت‌ها</th><td><input type="text" name="color_ink2" value="<?php echo esc_attr( $s['color_ink2'] ); ?>" class="soswp-color-field"></td></tr>
					<tr><th>قرمز هشدار (Signal)</th><td><input type="text" name="color_signal" value="<?php echo esc_attr( $s['color_signal'] ); ?>" class="soswp-color-field"></td></tr>
					<tr><th>کهربایی (Beacon)</th><td><input type="text" name="color_beacon" value="<?php echo esc_attr( $s['color_beacon'] ); ?>" class="soswp-color-field"></td></tr>
					<tr><th>سبز رفع‌شده (Pulse)</th><td><input type="text" name="color_pulse" value="<?php echo esc_attr( $s['color_pulse'] ); ?>" class="soswp-color-field"></td></tr>
					<tr><th>متن روشن</th><td><input type="text" name="color_cloud" value="<?php echo esc_attr( $s['color_cloud'] ); ?>" class="soswp-color-field"></td></tr>
					<tr><th>متن کم‌رنگ</th><td><input type="text" name="color_steel" value="<?php echo esc_attr( $s['color_steel'] ); ?>" class="soswp-color-field"></td></tr>
				</table>
			</div>

			<div class="soswp-tab-panel" data-tab="services" <?php echo 'services' !== $tab ? 'hidden' : ''; ?>>
				<p class="description">این لیست در بخش «سرویس‌ها»ی صفحه خانه نمایش داده می‌شود.</p>
				<div id="soswp-services-repeater">
					<?php foreach ( $s['services'] as $svc ) : ?>
						<div class="soswp-svc-row">
							<input type="text" name="svc_icon[]" value="<?php echo esc_attr( $svc['icon'] ); ?>" class="soswp-svc-icon" maxlength="4" title="ایموجی آیکون">
							<select name="svc_severity[]" class="soswp-svc-severity">
								<option value="critical" <?php selected( $svc['severity'], 'critical' ); ?>>بحرانی</option>
								<option value="high" <?php selected( $svc['severity'], 'high' ); ?>>جدی</option>
								<option value="normal" <?php selected( $svc['severity'], 'normal' ); ?>>متوسط</option>
							</select>
							<input type="text" name="svc_title[]" value="<?php echo esc_attr( $svc['title'] ); ?>" class="soswp-svc-title" placeholder="عنوان سرویس">
							<input type="text" name="svc_desc[]" value="<?php echo esc_attr( $svc['desc'] ); ?>" class="soswp-svc-desc" placeholder="توضیح کوتاه">
							<button type="button" class="button soswp-svc-remove">حذف</button>
						</div>
					<?php endforeach; ?>
				</div>
				<button type="button" class="button button-secondary" id="soswp-svc-add">+ افزودن سرویس جدید</button>

				<template id="soswp-svc-template">
					<div class="soswp-svc-row">
						<input type="text" name="svc_icon[]" value="🛠️" class="soswp-svc-icon" maxlength="4">
						<select name="svc_severity[]" class="soswp-svc-severity">
							<option value="critical">بحرانی</option>
							<option value="high">جدی</option>
							<option value="normal" selected>متوسط</option>
						</select>
						<input type="text" name="svc_title[]" value="" class="soswp-svc-title" placeholder="عنوان سرویس">
						<input type="text" name="svc_desc[]" value="" class="soswp-svc-desc" placeholder="توضیح کوتاه">
						<button type="button" class="button soswp-svc-remove">حذف</button>
					</div>
				</template>
			</div>

			<?php submit_button( 'ذخیره تنظیمات' ); ?>
		</form>
	</div>
	<?php
}

/** تزریق متغیرهای رنگی به‌صورت سراسری در <head> — پایه هماهنگی «یکپارچه» سایت */
function soswp_inline_color_vars() {
	$vars = array(
		'--ink'    => soswp_option( 'color_ink', '#101218' ),
		'--ink-2'  => soswp_option( 'color_ink2', '#171A22' ),
		'--signal' => soswp_option( 'color_signal', '#FF3B30' ),
		'--beacon' => soswp_option( 'color_beacon', '#FFB020' ),
		'--pulse'  => soswp_option( 'color_pulse', '#2ECC71' ),
		'--cloud'  => soswp_option( 'color_cloud', '#F5F6F8' ),
		'--steel'  => soswp_option( 'color_steel', '#8A8F9C' ),
	);
	echo "<style id='soswp-dynamic-vars'>:root{";
	foreach ( $vars as $name => $value ) {
		echo esc_html( $name ) . ':' . esc_html( $value ) . ';';
	}
	echo "}</style>\n";
}
add_action( 'wp_head', 'soswp_inline_color_vars', 5 );
